#!/bin/bash

emulator="$2"
fullfilename=$(basename "$1")
dirName=$(dirname "$1")
filename=$(printf '%q' "$fullfilename")
filenameNoExt="${filename%.*}"
extension="${filename##*.}"

retroarchbin="/usr/bin/retroarch"
retroarchcores="/usr/lib/libretro"
retroarchconfigs="/recalbox/share/system/configs/retroarch"
retroarchappendconfig="/recalbox/share/.RGB-Pi/retroarch_custom"
hdmitimings="/recalbox/share/.RGB-Pi/hdmi_timings"

# ****************************** MAME ****************************** 
if [[ "$emulator" == "mame" ]]; then
   . /recalbox/share/roms/mame/resolutions.cfg

	if [[ -n ${mame_games[$filename]} ]]; then

 		if [[ ${mame_games[$filename]} == "192-60" ]]; then ./$hdmitimings/vcgen_192-60.sh

                elif [[ ${mame_games[$filename]} == "224-60" ]]; then ./$hdmitimings/vcgen_224-60.sh

		elif [[ ${mame_games[$filename]} == "240-60" ]]; then ./$hdmitimings/vcgen_240-60.sh

                elif [[ ${mame_games[$filename]} == "256-55" ]]; then ./$hdmitimings/vcgen_256-55.sh

		fi

                retroarch -L $retroarchcores/mame078_libretro.so --config $retroarchconfigs/retroarchcustom.cfg --appendconfig $retroarchappendconfig/${mame_games[$filename]}.cfg $1
	else

            ./recalbox/share/.RGB-Pi/hdmi_timings/vcgen_standard.sh
            retroarch -L $retroarchcores/mame078_libretro.so --config $retroarchconfigs/retroarchcustom.cfg --appendconfig $retroarchappendconfig/standard.cfg $1

	fi
        ./recalbox/share/.RGB-Pi/hdmi_timings/vcgen_emulationstation.sh

fi
# ****************************************************************** 
