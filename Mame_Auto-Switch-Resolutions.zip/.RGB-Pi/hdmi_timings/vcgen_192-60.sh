#!/bin/bash

vcgencmd hdmi_timings 1920 1 50 200 250 250 1 3 9 3 0 0 0 60 0 38400000 1
tvservice -e "DMT 87"
fbset -depth 8 && fbset -depth 16

