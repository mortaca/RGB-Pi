#!/bin/bash

vcgencmd hdmi_timings 1888 1 48 184 232 278 1 3 10 6 0 0 0 55 0 38400000 1
tvservice -e "DMT 87"
fbset -depth 8 && fbset -depth 16

