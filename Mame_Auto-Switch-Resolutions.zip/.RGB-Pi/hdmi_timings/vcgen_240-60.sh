#!/bin/bash

vcgencmd hdmi_timings 1906 1 50 200 250 248 1 8 2 8 0 0 0 60 0 38400000 1
tvservice -e "DMT 87"
fbset -depth 8 && fbset -depth 16

