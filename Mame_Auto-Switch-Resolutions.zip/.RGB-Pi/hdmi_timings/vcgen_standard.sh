#!/bin/bash

vcgencmd hdmi_timings 960 1 24 96 120 248 1 3 10 6 0 0 0 60 0 19200000 1
tvservice -e "DMT 87"
fbset -depth 8 && fbset -depth 16

