#!/bin/bash

vcgencmd hdmi_timings 1920 1 48 192 240 248 1 3 10 6 0 0 0 60 0 38400000 1
tvservice -e "DMT 87"
fbset -depth 8 && fbset -depth 16

