+----------+
| rgbpi-v6 |
+----------+

Fixed error favorites image theme path
Flat and forest themes: fba, mame, advmame logos with different colors
Flat and forest themes: fba, mame, advmame same vertical layout as base theme


+----------+
| rgbpi-v5 |
+----------+

Corrections in all 3 themes merged.
Simplifies xml structure of base theme.

+----------+
| rgbpi-v4 |
+----------+

Well... this this is the lost floppy

+----------+
| rgbpi-v3 |
+----------+

Corrected layout and text in rgbpi-base-v theme
Merged all H and V themes. The resulting themes are now back to:

rgbpi-base
rgbpi-flat
rgbpi-forest

+----------+
| rgbpi-v2 |
+----------+

Second version of the themes now using PNG images for batch processing convenience.
Themes have now 2 versions for horizontal and vertical screen orientation:

rgbpi-base-h
rgbpi-flat-h
rgbpi-forest-h
rgbpi-base-v
rgbpi-flat-v
rgbpi-forest-v

+----------+
| rgbpi-v1 |
+----------+

First version of the themes using SVG images:

rgbpi-base
rgbpi-flat
rgbpi-forest

+-------------------------+
| logos-base-svg-original |
+-------------------------+

Original SVG logos used in base theme.
Some logos which were in PNG have been vectorized into SVG format for improving the image scaling process.

+-------------------------+
| logos-flat-svg-original |
+-------------------------+

Original SVG logos used in flat and forest themes.