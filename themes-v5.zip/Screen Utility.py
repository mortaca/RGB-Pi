#!/usr/bin/python
# coding: utf-8

# IMPORTS
import struct
import time
import pygame
import sys
import os
sys.path.insert(0, '/recalbox/share/RGB-Pi/')
from pygame.locals import *

from Fonctions import *

# INITS
pygame.init()
pygame.mouse.set_visible(0)

# VARIABLES
state_up = 0
state_down = 0
state_left = 0
state_right = 0
threshold = 1000 # Analogic middle to debounce
joystick = 0 # 0 is the 1sf joystick

x_screen = 450
y_screen = 270

opt = 0
x = 0
y = 0
y_slide = 0

#positions and arrows color
data_x = 340
arrow_c = [255,255,0]

#files
sucfg = '/recalbox/share/RGB-Pi/su.cfg'

# FUNCTIONS
def text_print(txt, x, y, r, g, b):
	fullscreen.blit(myfont.render(txt, 1, (r,g,b)), (x, y))

def draw_arrow_left():
	fullscreen.blit((myfont.render('<<', 1, (arrow_c))), (data_x-(len(str(opt[option][2]))*8)-18, 50+y*20))

def draw_arrow_right():
	fullscreen.blit((myfont.render('>>', 1, (arrow_c))), (data_x+2, 50+y*20))

def save():
#definition of the output format: h size, h pos, v pos, rotate games, rotate system, last state of rotate system, stretch portables, emulationstation resolution, last emulationtstation resolution state.
	saveFile = open(sucfg, 'w')
	optS = str(opt[0][2]) + ' ' + str(opt[1][2]) + ' ' + str(opt[2][2]) + ' ' + str(opt[3][2]) + ' ' + str(opt[4][2]) + ' ' + str(opt[4][2]) + ' ' + str(opt[5][2]) + ' ' + str(opt[6][2]) + ' ' + str(opt[6][2])
	saveFile.write(optS)
	saveFile.close()

	if opt[4][2] != opt[4][3]:
		saveConftxt()
	if opt[6][2] != opt[6][3]:
		saveConftxt()

def saveConftxt():
#changes at points 5 and 7 from prevous states implies edit the config.txt and reboot the system.
		os.system('mount -o remount,rw /boot')
		os.system('mount -o remount,rw /')
		conftxt = open('/boot/config.txt', 'r')
		contents = conftxt.readlines()
		conftxt.close()

		
		if opt[6][2] != opt[6][3]:
			if opt[6][2] == 270:
	 			contents[0] = str(opt[6][4]) + '\n'
			elif opt[6][2] == 240:
	 			contents[0] = str(opt[6][5]) + '\n'

		if opt[4][2] != opt[4][3]:
			if opt[4][2] == 0:
	 			contents[1] = 'display_rotate=0' + '\n'
				#rgbpi-base
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorites/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorires/theme.xml')

				#rgbpi-forest
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorites/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorires/theme.xml')

				#rgbpi-flat
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorites/theme_h.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorires/theme.xml')
				#es_systems.cfg
				os.system('cp /recalbox/share_init/system/.emulationstation/es_systems_H.cfg /recalbox/share_init/system/.emulationstation/es_systems.cfg')

			elif opt[4][2] == 90:
	 			contents[1] = 'display_rotate=1' + '\n'
				#rgbpi-base
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorires/theme.xml')

				#rgbpi-forest
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorires/theme.xml')

				#rgbpi-flat
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorires/theme.xml')
				#es_systems.cfg
				os.system('cp /recalbox/share_init/system/.emulationstation/es_systems_V.cfg /recalbox/share_init/system/.emulationstation/es_systems.cfg')

			elif opt[4][2] == -90:
	 			contents[1] = 'display_rotate=3' + '\n'
				#rgbpi-base
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/common.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-base/favorires/theme.xml')

				#rgbpi-forest
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-forest/favorires/theme.xml')

				#rgbpi-flat
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/rgbpi.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/advmame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/mame/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/fba_libretro/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/config/theme.xml')
				os.system('cp /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorites/theme_v.xml /recalbox/share_init/system/.emulationstation/themes/rgbpi-flat/favorires/theme.xml')
				#es_systems.cfg
				os.system('cp /recalbox/share_init/system/.emulationstation/es_systems_V.cfg /recalbox/share_init/system/.emulationstation/es_systems.cfg')

		conftxt = open('/boot/config.txt', 'w')
		contents = "".join(contents)
		conftxt.write(contents)
		conftxt.close()
		os.system('reboot')

def test():

	timings_full_path = "/recalbox/share/RGB-Pi/Timings.cfg"
	ra_cfg_path ="/recalbox/share/RGB-Pi/Retroarch"	
	configgen_retroarchcustom = "/recalbox/share/system/configs/retroarch/retroarchcustom.cfg"
	
	save()

	pygame.quit()
	
	crt_open_screen_from_timings_cfg('neogeo',timings_full_path)
	commandline = "retroarch --config %s --appendconfig %s/%s.cfg " % (configgen_retroarchcustom,ra_cfg_path,'test')
	os.system(commandline)

	es_restore_screen()

	os.execl(sys.executable, sys.executable, *sys.argv)


# SET SCREEN
fullscreen = pygame.display.set_mode((x_screen,y_screen), FULLSCREEN)
fullscreen.fill((165,165,255))	

# FONT
myfont = pygame.font.Font("/recalbox/share/roms/config/PetMe64.ttf", 8)

# loading data from su.cfg
opt = [["1.HORIZONTAL ZOOM" ,"Affects only to games and test" , 0],
	["2.HORIZONTAL POSITION" , "Affects only to games and test" , 0],
	["3.VERTICAL POSITION" , "Affects only to games and test" , 0],
	["4.TATE GAMES ROTATION" , "Not PixelPerfect but playable on AdvMAME" , 0],
	["5.FRONTEND ROTATION" , "This option requires rotate your monitor" , 0, 0],
	["6.HANDHELD BEZELS" , "CAUTION!!! Long use can damage the screen" , 0],
	["7.FRONTEND RESOLUTION" , "Changes don't have effect inside the games" , 0, 0,'hdmi_timings=450 1 50 30 90 270 1 1 1 30 0 0 0 50 0 9600000 1 ', 'hdmi_timings=450 1 34 50 55 240 1 10 1 15 0 0 0 60 0 9600000 1'],
	["8.CENTERING TEST" , "To return from test press Hotkey + Start"],
	["9.SAVE AND EXIT" , "It's time to play"]]	

with open(sucfg, 'r') as file:
	for line in file:
		line = line.strip().split(' ')
		optl = line

		opt[0][2] = int(optl[0])
		opt[1][2] = int(optl[1])
		opt[2][2] = int(optl[2])
		opt[3][2] = int(optl[3])
		opt[4][2] = int(optl[4])
		opt[4][3] = int(optl[5])
		opt[5][2] = int(optl[6])
		opt[6][2] = int(optl[7])
		opt[6][3] = int(optl[8])


#joystick read
with open("/dev/input/js%s" % joystick, "rb") as f:
#with open("/dev/input/js0", "rb") as f:


# starting the main loop		
   running = 1
   while running:

	a = f.read(8)
	t, value, code, index = struct.unpack("<ihbb", a) # 4 bytes, 2 bytes, 1 byte, 1 byte
	#print("t: {:10d} ms, value: {:6d}, code: {:1d}, index: {:1d}".format(t, value, code, index))


	#button
	if code == 1 and value == 1:
		if y == 7 and opt[4][2] == opt[4][3] and opt[6][2] == opt[6][3]:
			test()
		elif y == 6:
			opt[option][2] = 270
		elif y < 6:
			opt[option][2] = 0
		elif y == 8:
               		save()
			pygame.quit()
        		sys.exit()

	#right		
	if code == 2 and index % 2 == 0:
		if value > 30000:
			if state_right == 0:
				state_right = value
				if y == 0:
					opt[0][2] += 1
				elif y == 1:
					opt[1][2] += 1
				elif y == 2:
					opt[2][2] += 1
				elif y == 3 and opt[3][2] < 0 and opt[4][2] == 0:
					opt[3][2] += 90
				elif y == 4 and opt[4][2] < 90:
					opt[4][2] += 90
					opt[3][2] = 0
				elif y == 5 and opt[5][2] == 0:
					opt[5][2] = 1
				elif y == 6 and opt[6][2] == 240:
					opt[6][2] = 270
		elif value < threshold:
			state_right = 0
			
	#left	
	if code == 2 and index % 2 == 0:
		if value < -30000:
			if state_left == 0:
				state_left = value
				if y == 0:
					opt[0][2] -= 1
				elif y == 1:
					opt[1][2] -= 1
				elif y == 2:
					opt[2][2] -= 1
				elif y == 3 and opt[3][2] > -90 and opt[4][2] == 0:
					opt[3][2] -= 90
				elif y == 4 and opt[4][2] > -90:
					opt[4][2] -= 90
					opt[3][2] = 0
				elif y == 5 and opt[5][2] == 1:
					opt[5][2] = 0
				elif y == 6 and opt[6][2] == 270:
					opt[6][2] = 240
		elif value < threshold:
			state_left = 0

	#up			
	if code == 2 and index % 2 == 1:
		if value < -30000:
			if state_up == 0:
				state_up = value
				if y > 0:
					y = y - 1
				elif y == 0:
					y = 8
		elif value < threshold:
			state_up = 0

	#down
	if code == 2 and index % 2 == 1:
		if value > 30000:
			if state_down == 0:
				state_down = value
				if y < 8:
					y = y + 1
			        elif y == 8:
					y = 0
		elif value < threshold:
			state_down = 0



	# SHOW BACKGROUND 		
	pygame.draw.rect(fullscreen, (66,66,231), (20,20,x_screen-40,y_screen-40), 0)

	#title and credits
	title = myfont.render("RGB-Pi Screen Utility v1.3", 1, (165,165,255))
	fullscreen.blit(title, (32, 28))
	text_print("by Ironic & aTg", 300, 28, 110, 110, 255)

	#last options	
	#text_print('last rotation = ' + str(opt[4][3]), 0, 0, 255, 0, 0)
	#text_print('last ES resolution = ' + str(opt[6][3] ), 0, 8, 255, 0, 0)	
	
	#list square
	pygame.draw.rect(fullscreen, (165,165,255), (32,44,x_screen-62,y_screen-90), 1)

	#list
	for i in range(0,9):
		option = y+y_slide
		fullscreen.blit((myfont.render(opt[i+y_slide][0], 1, (165,165,255))), (110, 50+i*20))
	

	# data values
	hsize = myfont.render(str(opt[0][2]), 1, (165,165,255))
	fullscreen.blit(hsize, (data_x-(len(str(opt[0][2]))*8), 50))

	hpos = myfont.render(str(opt[1][2]), 1, (165,165,255))
	fullscreen.blit(hpos, (data_x-(len(str(opt[1][2]))*8), 70))

	vpos = myfont.render(str(opt[2][2]), 1, (165,165,255))
	fullscreen.blit(vpos, (data_x-(len(str(opt[2][2]))*8), 90))

	rotg = myfont.render(str(opt[3][2]), 1, (165,165,255))
	fullscreen.blit(rotg, (data_x-(len(str(opt[3][2]))*8), 110))

	rots = myfont.render(str(opt[4][2]), 1, (165,165,255))
	fullscreen.blit(rots, (data_x-(len(str(opt[4][2]))*8), 130))

	strpor = myfont.render(str(opt[5][2]), 1, (165,165,255))
	fullscreen.blit(strpor, (data_x-(len(str(opt[5][2]))*8), 150))

	esres = myfont.render(str(opt[6][2]), 1, (165,165,255))
	fullscreen.blit(esres, (data_x-(len(str(opt[6][2]))*8), 170))

	# message if reboot is needed and deactivated options in red
	if opt[4][2] != 0:
		fullscreen.blit((myfont.render(opt[3][0], 1, (86,86,255))), (110, 110))
	if opt[4][2] != opt[4][3]:
		text_print('THE SYSTEM REBOOTS WHEN YOU EXIT', 100, 7, 255, 0, 0)
		fullscreen.blit((myfont.render(opt[7][0], 1, (86,86,255))), (110, 190))
	elif opt[6][2] != opt[6][3]:
		text_print('THE SYSTEM REBOOTS WHEN YOU EXIT', 100, 7, 255, 0, 0)
		fullscreen.blit((myfont.render(opt[7][0], 1, (86,86,255))), (110, 190))
	else:
		text_print('THE SYSTEM REBOOTS WHEN YOU EXIT', 100, 7, 165, 165, 255)

# list selection and square and arrows
	pygame.draw.rect(fullscreen, (165,165,255), (32,44+y*20,x_screen-62,20))
	fullscreen.blit((myfont.render(opt[option][0], 1, (66,66,231))), (110, 50+y*20))

	# data redraw
	if y < 7:
		
		listrndr = myfont.render(str(opt[option][2]), 1, (66,66,231))
		fullscreen.blit(listrndr, (data_x-(len(str(opt[option][2]))*8), 50+y*20))

	#option 1,2 & 3:
	if y < 3:
		draw_arrow_right()
		draw_arrow_left()

	#option 4
	if y == 3 and opt[3][2] < 0:
		draw_arrow_right()
	elif y == 3 and opt[3][2] == 0 and opt[4][2] == 0:
		draw_arrow_left()
	elif y == 3 and opt[4][2] != 0:
		fullscreen.blit((myfont.render(opt[option][0], 1, (136,136,255))), (110, 50+y*20))
			
	#option 5
	if y == 4 and opt[4][2] < 0:
		draw_arrow_right()
	elif y == 4 and opt[4][2] == 0:
		draw_arrow_right()
		draw_arrow_left()
	elif y == 4 and opt[4][2] > 0:
		draw_arrow_left()

	#option 6
	if y == 5:
		if opt[5][2] == 1:
			draw_arrow_left()
		else:
			draw_arrow_right()

	#option 7
	if y == 6:
		if opt[6][2] == 270:
			draw_arrow_left()
		else:
			draw_arrow_right()

	

	#option 8			
	if y == 7 and opt[4][2] != opt[4][3]:
			fullscreen.blit((myfont.render(opt[option][0], 1, (136,136,255))), (110, 50+y*20))
	elif y == 7 and opt[6][2] != opt[6][3]:
			fullscreen.blit((myfont.render(opt[option][0], 1, (136,136,255))), (110, 50+y*20))


	
		
	# SHOW description on bootom in yellow and case
	fullscreen.blit((myfont.render(opt[y+y_slide][1], 1, (255,255,0))), (38, y_screen-43))
	pygame.draw.rect(fullscreen, (165,165,255), (32,223,x_screen-62,16), 1)


	
	pygame.display.flip()



