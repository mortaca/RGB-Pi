﻿INSTRUCCIONES
=============

Pruebas realizadas con Recalbox 17.12.02 Pi3

1. Copiada imagen a SD de 32GB usando Etcher
2. Primer arranque de la SD hasta llegar a ES
3. Conexión via SSH a recalbox. Usuario/PWD : root/recalboxroot
4. Preparar montaje de escritura via comando :
    > mount -o remount,rw /
    > mount -o remount,rw /boot
5. Copiar libreadline.so.7 a /usr/lib y cambiar permisos a 755
6. Copiar libtinfo.so.5 a /usr/lib y cambiar permisos a 755
7. Borrar manualmente ./usr/sbin/parted
8. Copiar parted a ./usr/sbin y cambiar permisos a 755
9. Reducción de prueba de la partición via comando :
    > parted /dev/mmcblk0 resizepart 3 4096MB
10. Reinicio del sistema via comando (necesario para que se entere el kernel
    del resize) :
     > reboot
11. Borrar manualmente ./etc/init.d/S11share
12. Copiar S11share a ./etc/init.d y cambiar permisos a 755
13. Reinicio del sistema via comando :
     > reboot
14. Comprobar resultado via comando :
     > parted -s /dev/mmcblk0 -m unit Mb print free

NOTAS
=====

1. Los cambios en S11share están en las líneas 76-90.
2. En los pasos de arriba te indico el borrado manual de ficheros ya que yo
   tuve problemas al sobreescribir via FTP. La transferencia decía que estaba
   OK pero dejaba corruptos los ficheros.